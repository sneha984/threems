class Items{
  final String img;
  final String text;
  final String amount;
  final  value;

  Items({required this.img,required this.value,required this.text,required this.amount});

}