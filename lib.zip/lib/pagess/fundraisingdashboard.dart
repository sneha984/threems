import 'dart:ui';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:percent_indicator/percent_indicator.dart';


import 'package:flutter_svg/svg.dart';
import 'package:syncfusion_flutter_gauges/gauges.dart';
import 'package:threems/donate/flchart.dart';
import 'package:threems/pagess/fundrisingdasgboard2.dart';

import '../screens/charity/basic_details.dart';
import '../screens/splash_screen.dart';
import '../utils/themes.dart';


class FundRaisingDashboard extends StatefulWidget {
  const FundRaisingDashboard({Key? key}) : super(key: key);

  @override
  State<FundRaisingDashboard> createState() => _FundRaisingDashboardState();
}

class _FundRaisingDashboardState extends State<FundRaisingDashboard>with TickerProviderStateMixin {
  late  TabController _tabControllerrs;
  @override
  void initState() {
    _tabControllerrs = TabController(length: 4, vsync: this);
    _tabControllerrs.addListener(_handleTabSelection);

    super.initState();
  }
  void _handleTabSelection() {
    setState(() {
    });
  }
  @override
  void dispose() {
    super.dispose();
    _tabControllerrs.dispose();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Column(
        mainAxisSize: MainAxisSize.max,
        children: [
          Stack(
            children: [
              Container(
                height: scrHeight*0.45,
                width:scrWidth,
                decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Color(0xffA1FFC9),
                        Color(0xffFFFFFF),
                      ],
                    )
                ),
          ),
                Column(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    Padding(
                      padding:  EdgeInsets.only( top: scrHeight*0.095,
                      ),
                      child: Row(
                        children: [
                          GestureDetector(
                            onTap: (){
                              Navigator.pop(context);
                            },
                            child:  Padding(
                              padding: EdgeInsets.only(
                                  left: scrWidth*0.06,
                                  // bottom: scrHeight*0.02,
                                  right: scrWidth*0.04),
                              child:SvgPicture.asset("assets/icons/arrow.svg",),
                            ),
                          ),
                          Text("Fundraise Dashboard",style: TextStyle(
                              fontSize: scrWidth*0.045,
                              color: Colors.black,
                              fontFamily: 'Urbanist',
                              fontWeight: FontWeight.w700),),
                          SizedBox(width: scrWidth*0.13,),
                          InkWell(
                            onTap: (){
                              Navigator.push(context, MaterialPageRoute(builder: (context)=>BasicDetails()));

                            },
                            child: Container(
                              height: scrHeight*0.035,
                              width: scrWidth * 0.25,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(30),
                                color: primarycolor,
                              ),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  const Icon(
                                    Icons.add,
                                    size: 11,
                                    color: Colors.white,
                                  ),

                                  Text(
                                    "Create New",
                                    style: TextStyle(
                                        color: Colors.white,
                                        fontSize: CreateChitFont,
                                        fontFamily: 'Urbanist',
                                        fontWeight: FontWeight.w700),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: scrHeight*0.03,),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        Text("Recent Charity",style: TextStyle(
                            fontSize: scrWidth*0.04,
                            color: Colors.black,
                            fontFamily: 'Urbanist',
                            fontWeight: FontWeight.w500),),
                        SizedBox(width: scrWidth*0.22,),
                        GestureDetector(
                          onTap: (){
                            Navigator.push(context, MaterialPageRoute(builder: (context)=>Flchartpage()));
                          },
                          child: Text("VIEW ALL",style: TextStyle(
                              fontSize: scrWidth*0.033,
                              color: Colors.black,
                              fontFamily: 'Urbanist',
                              fontWeight: FontWeight.w700),),
                        ),
                      ],
                    ),
                    SizedBox(height: scrHeight*0.015,),
                    Container(
                      height: scrHeight*0.12,
                        width: scrWidth*0.88,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(9),
                        color: Colors.white,
                      ),
                      child: Row(
                        children: [
                          SizedBox(width: scrWidth*0.02,),
                          Stack(
                            children: [
                              Container(
                                width: scrWidth*0.3,
                                height: scrHeight*0.1,
                                decoration: BoxDecoration(
                                  image: DecorationImage(image: NetworkImage("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ9Fq34XkS4qJu18uu9U-VM0-KpLRQjH6EoMw&usqp=CAU"),fit: BoxFit.fill),
                                  borderRadius: BorderRadius.circular(10),
                                  color: Colors.grey,

                                ),
                              ),

                              Positioned(
                                top: 50,
                                bottom: 7,
                                left: 5,
                                right: 44,
                                child:ClipRRect(
                                  borderRadius: BorderRadius.all(Radius.circular(10)),
                                  child: BackdropFilter(
                                    filter: ImageFilter.blur(sigmaX: 4.0, sigmaY: 4.0),
                                    child: Center(
                                      child: Text("Disaster",style: TextStyle(
                                          fontSize: scrWidth*0.02,
                                          color: Colors.black,
                                          fontFamily: 'Urbanist',
                                          fontWeight: FontWeight.w700),),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          // SizedBox(width: ,),
                          Column(
                            children: [
                              SizedBox(height: scrHeight*0.015,),
                              Text("Urgent! Help the people in \nAssam ",style: TextStyle(
                                  fontSize: scrWidth*0.033,
                                  color: Colors.black,
                                  fontFamily: 'Urbanist',
                                  fontWeight: FontWeight.w600),),
                              SizedBox(height: scrHeight*0.03,),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                children: [
                                  Padding(
                                    padding:  EdgeInsets.only(left: scrWidth*0.05),
                                    child: GestureDetector(
                                      onTap: (){
                                        Navigator.push(context, MaterialPageRoute(builder: (context)=>FundRisingdashboardtwo()));
                                      },
                                      child: Container(
                                        width: scrWidth*0.2,
                                        height: scrHeight*0.023,
                                        decoration: BoxDecoration(
                                          borderRadius: BorderRadius.circular(5),
                                          color: Color(0xffF14336),

                                        ),
                                        child: Center(
                                          child: Text("IN REVIEW",style: TextStyle(
                                              fontSize: scrWidth*0.03,
                                              color: Colors.white,
                                              fontFamily: 'Urbanist',
                                              fontWeight: FontWeight.w700),),
                                        ),
                                      ),
                                    ),
                                  ),
                                  // SizedBox(width: 30,),
                                  Padding(
                                    padding:  EdgeInsets.only(left: scrWidth*0.2),
                                    child: SvgPicture.asset("assets/icons/shareicon.svg",),
                                  ),

                                ],
                              )
                            ],
                          )
                        ],
                      ),
                    ),
                    Padding(
                      padding:  EdgeInsets.only(top: scrHeight*0.025,right: scrWidth*0.45),
                      child: Text("Recent Charity Progress",style: TextStyle(
                          fontSize:  scrWidth*0.04,
                          color: Colors.black,
                          fontFamily: 'Urbanist',
                          fontWeight: FontWeight.w500),),
                    ),
                    SizedBox(height: scrHeight*0.01,),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          child: ClipRect(
                            child: Align(
                              heightFactor: 0.35,
                              child: Padding(
                                padding:  EdgeInsets.only(left: scrWidth*0.07,right: scrWidth*0.03),
                                //25
                                child: SfRadialGauge(
                                    axes: <RadialAxis>[
                                      RadialAxis(
                                        canScaleToFit: false,
                                        minimum: 0,
                                        interval: 1,
                                        maximum: 360,
                                        showLabels: false,
                                        showLastLabel: false,
                                        showTicks: false,
                                        startAngle: 270,
                                        endAngle: 270,
                                        radiusFactor: 0.95,
                                        axisLineStyle: AxisLineStyle(
                                          thickness:0.23,
                                          color: Colors.grey.withOpacity(0.2),
                                          thicknessUnit: GaugeSizeUnit.factor,
                                        ),
                                        pointers: <GaugePointer>[
                                          RangePointer(
                                              value: 0,
                                              enableAnimation: true,
                                              animationDuration: 6000,
                                              animationType: AnimationType.slowMiddle,
                                              width: 0.23,
                                              sizeUnit: GaugeSizeUnit.factor,
                                              cornerStyle: CornerStyle.startCurve,
                                              gradient: const SweepGradient(colors: <Color>[
                                                primarycolor,
                                                Color(0xff96c8aa)
                                              ],
                                                  stops: <double>[
                                                    0.74,
                                                    1.3
                                                  ])),
                                          MarkerPointer(
                                            enableAnimation: true,
                                            animationDuration: 6000,
                                            animationType: AnimationType.slowMiddle,
                                            value: 0,
                                            markerWidth: 17,
                                            markerHeight: 17,
                                            borderWidth:4,
                                            borderColor:  Color(0xff96c8aa),
                                            markerType: MarkerType.circle,
                                            color: Colors.white,
                                          )
                                        ],
                                        annotations:<GaugeAnnotation> [
                                          GaugeAnnotation(angle: 0,positionFactor: 0.18,
                                            widget:Text("0%",textAlign: TextAlign.center,style: TextStyle(
                                                fontSize: 23,fontFamily: 'Urbanist',fontWeight: FontWeight.w600
                                            ),),
                                          )

                                        ],

                                      )
                                    ]),
                              ),
                            ),
                          ),
                        ),
                        Padding(
                          padding:  EdgeInsets.only(right: scrWidth*0.35,top: scrHeight*0.024,),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Text("Raised",style: TextStyle(
                                  fontSize: scrWidth*0.034,
                                  color: Colors.black,
                                  fontFamily: 'Urbanist',
                                  fontWeight: FontWeight.w500),),
                              SizedBox(height: scrHeight*0.006,),

                              Text("₹0",style: TextStyle(
                                  fontSize: scrWidth*0.05,
                                  color: primarycolor,
                                  fontFamily: 'Urbanist',
                                  fontWeight: FontWeight.w700),),
                              SizedBox(height: scrHeight*0.004,),

                              Text("Out of ₹92,00,000 ",style: TextStyle(
                                  fontSize: scrWidth*0.034,
                                  color: Colors.black,
                                  fontFamily: 'Urbanist',
                                  fontWeight: FontWeight.w600),),
                              SizedBox(height: scrHeight*0.05,),
                            ],
                          ),
                        )

                      ],
                    ),
                    Padding(
                      padding:  EdgeInsets.only(top: scrHeight*0.02,right: scrWidth*0.7),
                      child: Text("Analytics",style: TextStyle(
                          fontSize: scrWidth*0.04,
                          color: Colors.black,
                          fontFamily: 'Urbanist',
                          fontWeight: FontWeight.w500),),
                    ),
                  ],
                ),


            ],
          ),
          SizedBox(height: scrHeight*0.025,),
          Padding(
            padding: EdgeInsets.only(left: scrWidth*0.05,right: scrWidth*0.05),
            child: TabBar(
                labelPadding: EdgeInsets.only(left: scrWidth*0.023,right: scrWidth*0.019),
                unselectedLabelStyle: TextStyle(
                    fontFamily: 'Poppins',fontSize: scrWidth*0.039,fontWeight: FontWeight.w400
                ),
                unselectedLabelColor: Color.fromRGBO(0, 0, 0, 0.3),
                indicatorSize: TabBarIndicatorSize.label,
                labelColor: Colors.white,
                labelStyle: TextStyle(
                    fontFamily: 'Poppins',fontSize: scrWidth*0.039,fontWeight: FontWeight.w400
                ),
                indicator: BoxDecoration(
                    borderRadius: BorderRadius.circular(60),
                    color: primarycolor
                ),
                isScrollable: true,
                controller: _tabControllerrs,
                tabs: [
                  Container(
                    height: scrHeight*0.043,
                    width:scrWidth*0.22,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(60),
                        color: Color.fromRGBO(0, 0, 0, 0.05)
                    ),
                    child: Center(child: Text("Day",)),),
                  Container(
                    height: scrHeight*0.043,
                    width:scrWidth*0.22,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(60),

                        color: Color.fromRGBO(0, 0, 0, 0.05)
                    ),
                    child: Center(child: Text("Week",)),),
                  Container(
                    height: scrHeight*0.043,
                    width:scrWidth*0.22,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(60),
                        color: Color.fromRGBO(0, 0, 0, 0.05)
                    ),
                    child: Center(child: Text("Month",)),),
                  Container(
                    height: scrHeight*0.043,
                    width:scrWidth*0.22,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(60),
                        color: Color.fromRGBO(0, 0, 0, 0.05)
                    ),
                    child: Center(child: Text("Year",)),),
                ]),
          ),
          Expanded(
            child: TabBarView(
                controller: _tabControllerrs,
                children: [
                  Center(
                    child: Text("No Analytics Here",style: TextStyle(
                      fontSize: scrWidth*0.03,
                      fontWeight: FontWeight.w600,
                      fontFamily: 'Urbanist',
                      color: Color(0xffA8A8A8)
                    ),),
                  ),
                  Center(
                    child: Text("No Analytics Here",style: TextStyle(
                        fontSize: scrWidth*0.03,
                        fontWeight: FontWeight.w600,
                        fontFamily: 'Urbanist',
                        color: Color(0xffA8A8A8)
                    ),),
                  ),
                  Center(
                    child: Text("No Analytics Here",style: TextStyle(
                        fontSize: scrWidth*0.03,
                        fontWeight: FontWeight.w600,
                        fontFamily: 'Urbanist',
                        color: Color(0xffA8A8A8)
                    ),),
                  ),
                  Center(
                    child: Text("No Analytics Here",style: TextStyle(
                        fontSize: scrWidth*0.03,
                        fontWeight: FontWeight.w600,
                        fontFamily: 'Urbanist',
                        color: Color(0xffA8A8A8)
                    ),),
                  ),                ]
            ),
          ),
        ],
      ),
    );
  }
}
