import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:threems/donate/sucess.dart';

import '../screens/splash_screen.dart';
import '../utils/themes.dart';

class PaymentPage extends StatefulWidget {
  const PaymentPage({Key? key}) : super(key: key);

  @override
  State<PaymentPage> createState() => _PaymentPageState();
}

class _PaymentPageState extends State<PaymentPage> {
  get valueAmountFocus => null;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              height: scrHeight*0.136,
              width: scrWidth,
              decoration: BoxDecoration(
                color: Colors.white,
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.shade100,
                    spreadRadius: 5,
                    blurRadius: 7,
                    offset: Offset(0, 3), // changes position of shadow
                  ),
                ],
              ),
              child:  Padding(
                padding: EdgeInsets.only(
                    top: scrHeight*0.07,),
                child: Row(
                  children: [
                    SizedBox(width: 18,),
                    GestureDetector(
                      onTap: (){
                        Navigator.pop(context);
                      },
                      child:  SvgPicture.asset("assets/icons/arrow.svg",),
                    ),
                    SizedBox(width: 15,),

                    Text("Make a Donation",style: TextStyle(
                        fontSize: scrWidth*0.045,
                        color: Colors.black,
                        fontFamily: 'Urbanist',
                        fontWeight: FontWeight.w700),),
                  ],
                ),
              ),
            ),
            SizedBox(height: 20,),
            Row(
              children: [
                SizedBox(width: 20,),
                Container(

                  width: 115,
                  height: 116,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(30),
                      image: DecorationImage(image: NetworkImage("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ9Fq34XkS4qJu18uu9U-VM0-KpLRQjH6EoMw&usqp=CAU"),fit: BoxFit.fill)

    ),
                ),
                SizedBox(width: 14,),
                Column(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("Urgent! Help the people in Assam \nplease all do help",style: TextStyle(
                        fontSize:scrWidth*0.036,
                        fontFamily: 'Urbanist',
                        fontWeight: FontWeight.w600)),
                    SizedBox(height: 8,),

                    Row(
                      children: [
                        Text("Rajesh Manohar",style: TextStyle(
                            fontSize:14,
                            color: Color(0xff827E7E),
                            fontFamily: 'Urbanist',
                            fontWeight: FontWeight.w500)),
                        SizedBox(width: 3,),
                        SvgPicture.asset("assets/icons/Frame (1).svg"),

                      ],
                    ),
                    SizedBox(height: 37,),




                  ],
                )
              ],
            ),
            SizedBox(height: 20,),
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(width: 23,),

                Container(
                    width: 85,
                    height: 38,
                    decoration: BoxDecoration(
                        color: Color(0xffF7F8F9),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: Color(0xffDADADA))),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Container(
                            height: 20,
                            width: 30,
                          decoration: BoxDecoration(
                            image: DecorationImage(image: AssetImage("assets/images/flag.png"),fit: BoxFit.fill)
                          ),
                        ),
                        Text(
                          "INR",
                          style: TextStyle(
                            fontSize: 15,
                            fontFamily: 'Urbanist',
                            fontWeight: FontWeight.w500,
                            color: Colors.black,
                          ),
                        ),
                      ],
                    )),
                SizedBox(width: 10,),

                Container(
                  width: 220,
                  height: 38,
                  padding: EdgeInsets.symmetric(
                    horizontal: scrWidth * 0.04,
                    vertical: 2,
                  ),
                  decoration: BoxDecoration(
                      color: textFormFieldFillColor,
                      border: Border.all(
                        color: Color(0xffDADADA),
                      ),
                      borderRadius: BorderRadius.circular(scrWidth * 0.026)),
                  child: Row(
                    children: [
                     SvgPicture.asset("assets/icons/₹.svg"),
                      Padding(
                        padding:  EdgeInsets.only(bottom: 10,left: 10),
                        child: Container(
                          height: 38,
                          width: 170,
                          child: TextFormField(
                            cursorHeight: scrWidth * 0.055,
                            cursorWidth: 1,
                            cursorColor: Colors.black,
                            style: TextStyle(
                              color: Colors.black,
                              fontWeight: FontWeight.w600,
                              fontSize: FontSize15,
                              fontFamily: 'Urbanist',
                            ),
                            keyboardType: TextInputType.number,
                            decoration: InputDecoration(

                              fillColor: textFormFieldFillColor,
                              filled: true,
                              contentPadding: EdgeInsets.only(left: 2,
                                   top: 8, bottom: 9),
                              disabledBorder: InputBorder.none,
                              enabledBorder: InputBorder.none,
                              errorBorder: InputBorder.none,
                              border: InputBorder.none,
                              // focusedBorder: UnderlineInputBorder(
                              //   borderSide: BorderSide(
                              //     color: primarycolor,
                              //     width: 2,
                              //   ),
                              // ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

              ],
            ),
            SizedBox(height: 15,),
            Row(
              children: [
                SizedBox(width: 23,),
                Text(
                  "Pay to",
                  style: TextStyle(
                    fontSize: 14,
                    fontFamily: 'Urbanist',
                    fontWeight: FontWeight.w500,
                    color: Color(0xff827E7E),
                  ),
                ),
                SizedBox(width: 10,),
                Container(
                    width: 265,
                    height: 38,
                    decoration: BoxDecoration(
                        color: Color(0xffF7F8F9),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: Color(0xffDADADA))),
                    child: Row(
                      children: [
                        SizedBox(width: 15,),
                        Text(
                          "+91 9072318094",
                          style: TextStyle(
                            fontSize: 20,
                            fontFamily: 'Urbanist',
                            fontWeight: FontWeight.w600,
                            color: Colors.black,
                          ),
                        ),
                        SizedBox(width: 40,),

                        SvgPicture.asset("assets/icons/copy.svg"),
                        SizedBox(width: 5,),

                        Text(
                          "copy",
                          style: TextStyle(
                            fontSize: 12,
                            fontFamily: 'Urbanist',
                            fontWeight: FontWeight.w500,
                            color: Colors.black,
                          ),
                        ),


                      ],
                    )),

              ],
            ),
            SizedBox(height: 15,),

            Row(
              children: [
                SizedBox(width: 23,),

                Text(
                  "Accepted UPI Apps",
                  style: TextStyle(
                    fontSize: 14,
                    fontFamily: 'Urbanist',
                    fontWeight: FontWeight.w500,
                    color: Color(0xff827E7E),
                  ),
                ),
                SizedBox(width: 40,),

                Container(
                  height: 20,
                    width: 20,
                    child: Image(image: AssetImage("assets/images/gpay.png"))),
                SizedBox(width: 5,),

                Container(
                    height: 20,
                    width: 15,
                    child: Image(image: AssetImage("assets/images/phonepe.png"))),
                SizedBox(width: 5,),

                Container(
                    height: 20,
                    width: 40,
                    child: Image(image: AssetImage("assets/images/paytm (1).png"))),
                SizedBox(width: 5,),

                Container(
                    height: 20,
                    width: 15,
                    child: Image(image: AssetImage("assets/images/whatsp pay.png"))),
                SizedBox(width: 5,),

                Container(
                    height: 20,
                    width: 45,
                    child: Image(image: AssetImage("assets/images/amaz pay (1).png"))),
              ],
            ),
            SizedBox(height: 10,),


            Container(
              height: 190,
              width: 320,
              decoration: BoxDecoration(
                color: Colors.green,
                borderRadius: BorderRadius.circular(20),
              ),
            ),
            SizedBox(height: 25,),

            DottedBorder(
              padding: EdgeInsets.all(0),
              borderType: BorderType.RRect,
              radius: Radius.circular(8),
              color: Color(0xffDADADA),
              dashPattern: [4,4],
              strokeWidth: 2,
              child: Container(
                height: 64,
                width: 320,
                decoration: BoxDecoration(
                  color: Color(0xffF7F8F9),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SvgPicture.asset(
                      "assets/images/Group 135.svg",
                    ),
                    SizedBox(
                      width: scrWidth * 0.02,
                    ),
                    Text(
                      "Upload Screenshot",
                      style: TextStyle(
                        color: Color(0xff8391A1),
                        fontSize: 15,
                        fontFamily: 'Urbanist',
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(height: 10,),
            Text(
              "after the verification of screenshot your donation will appear on this charity",
              style: TextStyle(
                color: Color(0xff827E7E),
                fontSize: 10,
                fontFamily: 'Urbanist',
                fontWeight: FontWeight.w500,
              ),
            ),
            SizedBox(height: 27,),

            GestureDetector(
              onTap: (){
                Navigator.push(context, MaterialPageRoute(builder: (context)=>Sucesspage()));
              },
              child: Container(
          height: 45,
          width: 320,
          decoration: BoxDecoration(
              color: primarycolor,
              borderRadius: BorderRadius.circular(8),
          ),
                child: Center(
                  child: Text(
                    "DONATE NOW",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 13,
                      fontFamily: 'Urbanist',
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
              ),
            ),

          ],
        ),
      ),


    );
  }
}
