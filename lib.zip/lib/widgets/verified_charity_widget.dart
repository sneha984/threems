import 'dart:ui';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:threems/screens/splash_screen.dart';
import 'package:percent_indicator/percent_indicator.dart';
import 'package:intl/intl.dart';
import 'package:threems/utils/dummy.dart';
import '../utils/themes.dart';

class VerifiedCharityWidget extends StatefulWidget {
  const VerifiedCharityWidget({
    super.key,
  });

  @override
  State<VerifiedCharityWidget> createState() => _VerifiedCharityWidgetState();
}

class _VerifiedCharityWidgetState extends State<VerifiedCharityWidget> {
  var currencyConvert = NumberFormat.currency(
    locale: 'HI',
    symbol: '₹ ',
  );
  @override
  Widget build(BuildContext context) {
    return Container(
      // height: 277,
      height: scrWidth * .68,
      width: scrWidth,
      // color: Colors.pink,
      // margin: EdgeInsets.symmetric(
      //     vertical: scrWidth * 0.02, horizontal: scrWidth * 0.0),
      child: ListView.builder(
        physics: BouncingScrollPhysics(),
        primary: true,
        scrollDirection: Axis.horizontal,
        // separatorBuilder: (context, index) => SizedBox(
        //   width: 10,
        // ),

        itemCount: verifiedCharities.length,
        itemBuilder: (context, index) => Padding(
          padding: EdgeInsets.symmetric(
              horizontal: scrWidth * 0.045, vertical: scrWidth * 0.04),
          child: Container(
            height: scrWidth * .745,
            // height: 277,
            // width: 188,
            width: scrWidth * .522,
            decoration: BoxDecoration(
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.08),
                  offset: const Offset(0, 4),
                  spreadRadius: 3,
                  blurRadius: 20,
                ),
              ],
              color: Colors.white,
              borderRadius: BorderRadius.circular(scrWidth * 0.07),
            ),
            child: Column(
              // mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Stack(
                  children: [
                    Container(
                      height: scrWidth * 0.3,
                      width: scrWidth * .522,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.only(
                              topRight: Radius.circular(scrWidth * 0.07),
                              topLeft: Radius.circular(scrWidth * 0.07))),
                      child: ClipRRect(
                        borderRadius: BorderRadius.only(
                          topRight: Radius.circular(scrWidth * 0.07),
                          topLeft: Radius.circular(scrWidth * 0.07),
                        ),
                        child: CachedNetworkImage(
                          imageUrl: verifiedCharities[index]['image'],
                          fit: BoxFit.fill,
                        ),
                      ),
                    ),
                    Positioned(
                      // bottom: 14,
                      bottom: scrWidth * 0.03,
                      left: scrWidth * 0.035,
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(scrWidth * 0.039),
                        child: BackdropFilter(
                          filter: ImageFilter.blur(
                            sigmaX: scrWidth * 0.028,
                            sigmaY: scrWidth * 0.028,
                          ),
                          child: Container(
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.3),
                              borderRadius:
                                  BorderRadius.circular(scrWidth * 0.039),
                            ),
                            // width: 83,
                            // height: 24,
                            width: scrWidth * 0.23,
                            height: scrWidth * 0.0683,
                            child: Center(
                              child: Text(
                                verifiedCharities[index]['category'],
                                style: TextStyle(
                                  fontWeight: FontWeight.w700,
                                  fontSize: FontSize13,
                                  fontFamily: 'Urbanist',
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                Container(
                  // color: Colors.green,
                  height: scrWidth * 0.28,
                  width: scrWidth * .522,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding:
                            EdgeInsets.symmetric(horizontal: scrWidth * 0.035),
                        child: Text(
                          verifiedCharities[index]['title'],
                          style: TextStyle(
                            fontWeight: FontWeight.w600,
                            fontSize: FontSize13,
                            fontFamily: 'Urbanist',
                          ),
                        ),
                      ),
                      Padding(
                        padding:
                            EdgeInsets.symmetric(horizontal: scrWidth * 0.005),
                        child: LinearPercentIndicator(
                          //leaner progress bar
                          animation: true,
                          animationDuration: 1000,
                          lineHeight: 3,
                          width: 182,
                          percent: verifiedCharities[index]['percetage'],
                          alignment: MainAxisAlignment.start,
                          barRadius: Radius.circular(1.5),

                          progressColor: Color(0xff343434),
                          backgroundColor: Color(0xffE9F6FF),
                        ),
                      ),
                      Padding(
                          padding: EdgeInsets.symmetric(
                              horizontal: scrWidth * 0.035),
                          child: Text(
                            currencyConvert.format(
                              verifiedCharities[index]['amount'],
                            ),
                            style: TextStyle(
                              color: primarycolor,
                              fontWeight: FontWeight.w600,
                              fontSize: FontSize14,
                              fontFamily: 'Urbanist',
                            ),
                          ))
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
