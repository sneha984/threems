import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:threems/screens/charity/payment.dart';
import '../../utils/themes.dart';
import '../../widgets/percentage_widget.dart';
import '../splash_screen.dart';
import 'cause_details.dart';

class VerificationDetails extends StatefulWidget {
  const VerificationDetails({super.key});

  @override
  State<VerificationDetails> createState() => _VerificationDetailsState();
}

class _VerificationDetailsState extends State<VerificationDetails> {
  bool photo = true;
  bool docs = true;

  final FocusNode youtubeLinkNode = FocusNode();

  @override
  void initState() {
    youtubeLinkNode.addListener(() {
      setState(() {});
    });

    super.initState();
  }

  @override
  void dispose() {
    youtubeLinkNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(kToolbarHeight),
        child: Container(
          decoration: BoxDecoration(boxShadow: [
            BoxShadow(
                color: Colors.black.withOpacity(0.05),
                offset: Offset(0, 4),
                blurRadius: 25),
          ]),
          child: AppBar(
            elevation: 0,
            backgroundColor: Colors.white,
            leading: InkWell(
              onTap: () {
                Navigator.pop(context);
              },
              child: Container(
                // color: Colors.red,
                width: scrWidth*0.02,
                height: scrHeight*0.02,
                padding: EdgeInsets.all(scrWidth * 0.056),
                child: SvgPicture.asset(
                  'assets/icons/back.svg',
                  width: scrWidth*0.03,
                  height: scrHeight*0.02,
                  fit: BoxFit.contain,
                ),
              ),
            ),
            title: Text(
              "Create Charity",
              style: TextStyle(
                  fontSize: FontSize17,
                  fontFamily: 'Urbanist',
                  fontWeight: FontWeight.w600,
                  color: Colors.black),
            ),
          ),
        ),
      ),
      body: Padding(
        padding: EdgeInsets.only(
          left: padding15, right: padding15, top: scrWidth * 0.025,
          // vertical: scrWidth * 0.05,
        ),
        child: SingleChildScrollView(
          physics: BouncingScrollPhysics(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "VERIFICATION DETAILS",
                    style: TextStyle(
                        fontSize: FontSize16,
                        fontFamily: 'Urbanist',
                        fontWeight: FontWeight.w700,
                        color: Colors.black),
                  ),
                  PercentageWidget(percent: 75),
                ],
              ),
              SizedBox(
                height: scrWidth * 0.08,
              ),
              Row(
                mainAxisAlignment:
                    photo ? MainAxisAlignment.end : MainAxisAlignment.start,
                children: [
                  Text(
                    "Upload Photos",
                    style: TextStyle(
                      fontSize: FontSize15,
                      fontFamily: 'Urbanist',
                      fontWeight: FontWeight.w500,
                      color: photo ? primarycolor : Color(0xff8391A1),
                    ),
                  ),
                  photo ? SizedBox(width: scrWidth * 0.01) : SizedBox(),
                  photo
                      ? SizedBox(
                          child: SvgPicture.asset(
                            'assets/icons/uploaded.svg',
                            color: primarycolor,
                          ),
                        )
                      : SizedBox()
                ],
              ),
              SizedBox(
                height: scrWidth * 0.02,
              ),
              photo
                  ? Container(
                      height:scrHeight*0.16,
                      width: scrWidth*1,
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: CachedNetworkImage(
                          imageUrl:
                              'https://www.who.int/images/default-source/health-and-climate-change/rescue-operation-haiti-flood-c-un-photo-marco-dormino.tmb-1920v.jpg',
                          fit: BoxFit.cover,
                        ),
                      ),
                    )
                  : Container(
                height:scrHeight*0.16,
                width: scrWidth*1,
                      decoration: BoxDecoration(
                        color: Color(0xffF7F8F9),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(
                          color: Color(0xffDADADA),
                        ),
                      ),
                      child: Center(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            SvgPicture.asset(
                              'assets/icons/camera2.svg',
                              color: Color(0xff8391A1),
                            ),
                            SizedBox(
                              width: scrWidth * 0.04,
                            ),
                            Text(
                              'Upload Cover Photo',
                              style: TextStyle(
                                fontSize: FontSize15,
                                fontFamily: 'Urbanist',
                                fontWeight: FontWeight.w500,
                                color: Color(0xff8391A1),
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
              SizedBox(
                height: scrWidth * 0.02,
              ),
              docs
                  ? Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Text(
                          "Documents Uploaded",
                          style: TextStyle(
                            fontSize: FontSize15,
                            fontFamily: 'Urbanist',
                            fontWeight: FontWeight.w500,
                            color: primarycolor,
                          ),
                        ),
                        SizedBox(width: scrWidth * 0.01),
                        SizedBox(
                          child: SvgPicture.asset(
                            'assets/icons/uploaded.svg',
                            color: primarycolor,
                          ),
                        )
                      ],
                    )
                  : SizedBox(),
              SizedBox(
                height: scrWidth * 0.02,
              ),
              docs ? Container(
                      height: scrHeight*0.19,
                      width: scrWidth,
                      child: ListView.separated(
                        physics: BouncingScrollPhysics(),
                        separatorBuilder: (context, index) => SizedBox(
                          width: scrWidth * 0.028,
                        ),
                        scrollDirection: Axis.horizontal,
                        itemCount: 4,
                        itemBuilder: (context, index) {
                          return Container(
                            height: scrHeight*0.19,
                            width: scrWidth*0.3,
                            decoration: BoxDecoration(
                              // color: Colors.pink,
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(8),
                              child: CachedNetworkImage(
                                imageUrl:
                                    'https://templatelab.com/wp-content/uploads/2016/03/Company-Letterhead-Template-1-TemplateLab-Exclusive-e1487297202368-790x1022.jpg',
                                fit: BoxFit.cover,
                              ),
                            ),
                          );
                        },
                      ),
                    )
                  : Container(
                      width: scrWidth,
                      height: textFormFieldHeight45,
                      padding: EdgeInsets.symmetric(
                        horizontal: scrWidth * 0.015,
                        vertical: scrHeight*0.002,
                      ),
                      decoration: BoxDecoration(
                        color: textFormFieldFillColor,
                        border: Border.all(
                          color: Color(0xffDADADA),
                        ),
                        borderRadius: BorderRadius.circular(scrWidth * 0.026),
                      ),
                      child: Padding(
                        padding:  EdgeInsets.symmetric(horizontal: scrHeight*0.03),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              "Upload Documents",
                              style: TextStyle(
                                color: Color(0xff8391A1),
                                fontWeight: FontWeight.w500,
                                fontSize: FontSize15,
                                fontFamily: 'Urbanist',
                              ),
                            ),
                            SvgPicture.asset(
                              'assets/icons/camera2.svg',
                              color: Color(0xff8391A1),
                            ),
                          ],
                        ),
                      ),
                    ),
              SizedBox(
                height: scrWidth * 0.06,
              ),
              Text(
                'Tag the links of Videos for know more about the situation',
                style: TextStyle(
                  color: Color(0xff8391A1),
                  fontWeight: FontWeight.w500,
                  fontSize: FontSize15,
                  fontFamily: 'Urbanist',
                ),
              ),
              SizedBox(
                height: scrWidth * 0.04,
              ),
              Container(
                width: scrWidth,
                height: textFormFieldHeight45,
                padding: EdgeInsets.symmetric(
                  horizontal: scrWidth * 0.015,
                  vertical: scrHeight*0.002,
                ),
                decoration: BoxDecoration(
                  border: Border.all(
                    color: Color(0xffDADADA),
                  ),
                  color: textFormFieldFillColor,
                  borderRadius: BorderRadius.circular(scrWidth * 0.026),
                ),
                child: TextFormField(
                  focusNode: youtubeLinkNode,
                  cursorHeight: scrWidth * 0.055,
                  cursorWidth: 1,
                  cursorColor: Colors.black,
                  style: TextStyle(
                    color: Colors.black,
                    fontWeight: FontWeight.w600,
                    fontSize: FontSize15,
                    fontFamily: 'Urbanist',
                  ),
                  decoration: InputDecoration(
                    labelText: 'Paste the link',
                    labelStyle: TextStyle(
                      color: youtubeLinkNode.hasFocus
                          ? primarycolor
                          : textFormUnFocusColor,
                      fontWeight: FontWeight.w500,
                      fontSize: FontSize15,
                      fontFamily: 'Urbanist',
                    ),
                    fillColor: textFormFieldFillColor,
                    filled: true,
                    prefixIcon: SvgPicture.asset(
                      'assets/icons/youtube.svg',
                      width: scrWidth*0.03,
                      height: scrHeight*0.02,
                    ),
                    contentPadding: EdgeInsets.only(
                        left: scrWidth*0.03, top: scrHeight*0.006, bottom: scrWidth * 0.033),
                    disabledBorder: InputBorder.none,
                    enabledBorder: InputBorder.none,
                    errorBorder: InputBorder.none,
                    border: InputBorder.none,
                    focusedBorder: UnderlineInputBorder(
                      borderSide: BorderSide(
                        color: primarycolor,
                        width: 2,
                      ),
                    ),
                  ),
                ),
              ),
              SizedBox(
                height: scrWidth * 0.04,
              ),
              SizedBox(
                height: scrHeight*0.1,
              ),
              GestureDetector(
                onTap: () {
                  Navigator.push(
                      context,
                      CupertinoPageRoute(
                        builder: (context) => PaymentSucessful(),
                      ));
                },
                child:Container(
                  height: scrHeight*0.065,
                  decoration: BoxDecoration(
                      color: primarycolor,
                      borderRadius: BorderRadius.circular(17)),
                  margin: EdgeInsets.symmetric(vertical: scrWidth*0.03, horizontal: scrHeight*0.06),
                  child: Center(
                      child: Text(
                        "Continue",
                        style: TextStyle(color: Colors.white),
                      )),
                )
              ),
            ],
          ),
        ),
      ),
    );
  }
}
