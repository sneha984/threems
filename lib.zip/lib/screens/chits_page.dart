import 'package:badges/badges.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:threems/screens/splash_screen.dart';

import '../utils/themes.dart';

class SubPage extends StatefulWidget {
  const SubPage({Key? key}) : super(key: key);

  @override
  State<SubPage> createState() => _SubPageState();
}

class _SubPageState extends State<SubPage> with TickerProviderStateMixin {
  int selectedIndex = 0;

  late TabController _tabController;


  @override
  void initState() {
    _tabController = TabController(length: 2, vsync: this);

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      appBar: AppBar(
        toolbarHeight: 81,
        shadowColor: Colors.grey,

        elevation: 0.5,
        backgroundColor: Colors.white,

        leading: Padding(
          padding:  EdgeInsets.only(top: scrHeight*0.04,left: scrWidth*0.08),
          child: IconButton(
            onPressed: () {
              Navigator.pop(context);
            },
            icon: const Icon(
              Icons.arrow_back,
              color: Colors.black,
              size: 18,
            ),
          ),
        ),
        title: Padding(
          padding:  EdgeInsets.only(top: scrHeight*0.04),
          child: Text(
            "Chits",
            style: TextStyle(
                fontSize: ChitsFont,
                color: Colors.black,
                fontFamily: 'Urbanist',
                fontWeight: FontWeight.w700),
          ),
        ),
        actions: [
          Padding(
            padding:  EdgeInsets.only(right: scrWidth*0.07,top: scrHeight*0.056,bottom: scrHeight*0.015),
            child: Container(
              height: scrHeight*0.08,
              width: scrWidth * 0.25,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(30),
                color: primarycolor,
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(
                    Icons.add,
                    size: 11,
                    color: Colors.white,
                  ),

                  Text(
                    "Create Chit",
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: CreateChitFont,
                        fontFamily: 'Urbanist',
                        fontWeight: FontWeight.w700),
                  )
                ],
              ),
            ),
          ),
        ],
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          SizedBox(
            height: scrHeight * 0.022,
          ),
          Container(

            height: scrHeight * 0.055,
            width: scrWidth * 0.9,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(10),
            ),
            child: TabBar(
              isScrollable: false,
              unselectedLabelColor: primarycolor,
              labelColor: Colors.white,
              controller: _tabController,
              indicatorSize: TabBarIndicatorSize.tab,
              indicatorPadding:
              EdgeInsets.only(bottom:scrHeight*0.007, top: scrHeight*0.007, left: scrWidth*0.009, right: scrWidth*0.009),
              indicator: BoxDecoration(
                color: primarycolor,
                borderRadius: BorderRadius.circular(10),
              ),
              tabs: [
                Container(
                  width: scrWidth * 0.19,
                  height: scrHeight * 0.12,
                  child: const Center(
                    child: Text(
                      "New Chits",
                      style: TextStyle(fontSize: 12,
                          fontFamily: 'Urbanist', fontWeight: FontWeight.w500),
                    ),
                  ),
                ),
                Container(
                  width: scrWidth * 0.26,
                  height: scrHeight * 0.11,
                  child: const Center(
                    child: Text(
                      "Vacant Chits",
                      style: TextStyle(fontSize: 12,
                          fontFamily: 'Urbanist', fontWeight: FontWeight.w500),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
              child: TabBarView(
                controller: _tabController,
                children: [
                  Container(
                    child: Column(
                      children: [
                        SizedBox(
                          height: scrHeight *0.008,
                        ),
                        ListView.builder(
                            scrollDirection: Axis.vertical,
                            shrinkWrap: true,
                            itemCount: 2, // the length
                            itemBuilder: (context, index) {
                              return Column(
                                children: [
                                  Container(
                                    height: scrHeight * 0.2,
                                    // width: scrWidth*0.9,
                                    child: Card(
                                      semanticContainer: true,
                                      margin: EdgeInsets.all(10),
                                      color: Colors.white,
                                      elevation: 2,
                                      shadowColor: Colors.blueGrey.withOpacity(0.3),
                                      shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(8)),
                                      child: Column(
                                        children: [
                                          Row(
                                            mainAxisAlignment:
                                            MainAxisAlignment.start,
                                            crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                            children: [
                                              Padding(
                                                padding: EdgeInsets.only(
                                                    left: scrWidth*0.025,
                                                    right:scrWidth*0.025,
                                                    bottom: scrWidth*0.025,
                                                    top: scrWidth*0.04
                                                ),
                                                child: Container(
                                                  width: scrWidth * 0.15,
                                                  height: scrHeight * 0.07,
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                    BorderRadius.circular(14),
                                                    color: secondarycolor,
                                                  ),
                                                ),
                                              ),
                                              Column(
                                                crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                                children: [
                                                  SizedBox(
                                                    height: scrHeight * 0.024,
                                                  ),
                                                  Text(
                                                    "Name",
                                                    style: TextStyle(
                                                        fontSize: CardFont1,
                                                        color: Colors.grey,
                                                        fontFamily: 'Urbanist',
                                                        fontWeight:
                                                        FontWeight.w500),
                                                  ),
                                                  Text(
                                                    "New Chitti One",
                                                    style: TextStyle(
                                                      fontSize: CardFont2,
                                                      fontWeight: FontWeight.w700,
                                                      fontFamily: 'Urbanist',
                                                    ),
                                                  ),
                                                  SizedBox(
                                                    height:scrHeight* 0.005,
                                                  ),
                                                  Row(
                                                    mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceEvenly,
                                                    crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                    children: [
                                                      Text(
                                                        "Duration",
                                                        style: TextStyle(
                                                            fontSize: CardFont1,
                                                            color: Colors.grey,
                                                            fontFamily: 'Urbanist',
                                                            fontWeight:
                                                            FontWeight.w500),
                                                      ),
                                                      SizedBox(
                                                        width: scrWidth * 0.47,
                                                      ),
                                                      Text(
                                                        "Value",
                                                        style: TextStyle(
                                                            fontSize: CardFont1,
                                                            color: Colors.grey,
                                                            fontFamily: 'Urbanist',
                                                            fontWeight:
                                                            FontWeight.w500),
                                                      ),
                                                    ],
                                                  ),
                                                  Row(
                                                    children: [
                                                      Text(
                                                        "25 Months",
                                                        style: TextStyle(
                                                          fontSize: CardFont2,
                                                          fontWeight:
                                                          FontWeight.w700,
                                                          fontFamily: 'Urbanist',
                                                          color: primarycolor,
                                                        ),
                                                      ),
                                                      SizedBox(
                                                        width: scrWidth * 0.34,
                                                      ),
                                                      Text(
                                                        "₹50.000",
                                                        style: TextStyle(
                                                          fontSize: CardFont2,
                                                          fontWeight:
                                                          FontWeight.w700,
                                                          fontFamily: 'Urbanist',
                                                          color: primarycolor,
                                                        ),
                                                      )
                                                    ],
                                                  ),
                                                ],
                                              ),
                                            ],
                                          ),
                                          Divider(
                                            indent: 30,
                                            endIndent: 30,
                                          ),
                                          Padding(
                                            padding:  EdgeInsets.only(right: scrWidth*0.09),
                                            child: Column(
                                              crossAxisAlignment:
                                              CrossAxisAlignment.end,
                                              children: [
                                                // ElevatedButton(
                                                //   child: Text('Press me!'),s
                                                //   onPressed: () {
                                                //     print('Hello');
                                                //   },
                                                //   style: ElevatedButton.styleFrom(
                                                //         primary: Colors.purple,
                                                //         // padding: EdgeInsets.symmetric(horizontal: 50, vertical: 20),
                                                //         textStyle: TextStyle(
                                                //             fontSize: 10,
                                                //             fontWeight: FontWeight.bold)),
                                                //
                                                // ),
                                                Text(
                                                  "Subscription",
                                                  style: TextStyle(
                                                      fontSize: CardFont1,
                                                      color: Colors.grey,
                                                      fontFamily: 'Urbanist',
                                                      fontWeight: FontWeight.w500),
                                                ),
                                                SizedBox(height: scrHeight*0.001,),
                                                Row(
                                                  mainAxisAlignment:
                                                  MainAxisAlignment.end,
                                                  children: [
                                                    Text(
                                                      "₹2.000",
                                                      style: TextStyle(
                                                        fontSize: CardFont2,
                                                        fontWeight: FontWeight.w700,
                                                        fontFamily: 'Urbanist',
                                                        color: primarycolor,
                                                      ),
                                                    ),
                                                    Text(
                                                      "/month",
                                                      style: TextStyle(
                                                          fontSize: CardFont1,
                                                          color: Colors.grey,
                                                          fontFamily: 'Urbanist',
                                                          fontWeight:
                                                          FontWeight.w500),
                                                    ),
                                                  ],
                                                )
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              );
                            })
                      ],
                    ),
                  ),
                  Container(
                    child: Column(
                      children: [
                        SizedBox(
                          height: scrHeight *0.008,
                        ),
                        ListView.builder(
                            scrollDirection: Axis.vertical,
                            shrinkWrap: true,
                            itemCount: 2, // the length
                            itemBuilder: (context, index) {
                              return Column(
                                children: [
                                  Container(
                                    height: scrHeight * 0.2,
                                    // width: scrWidth*0.9,
                                    child: Card(
                                      semanticContainer: true,
                                      margin: EdgeInsets.all(10),
                                      color: Colors.white,
                                      elevation: 2,
                                      shadowColor: Colors.blueGrey.withOpacity(0.3),
                                      shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(8)),
                                      child: Column(
                                        children: [
                                          Row(
                                            mainAxisAlignment:
                                            MainAxisAlignment.start,
                                            crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                            children: [
                                              Padding(
                                                padding: EdgeInsets.only(
                                                    left: scrWidth*0.025,
                                                    right:scrWidth*0.025,
                                                    bottom: scrWidth*0.025,
                                                    top: scrWidth*0.04
                                                ),
                                                child: Container(
                                                  width: scrWidth * 0.15,
                                                  height: scrHeight * 0.07,
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                    BorderRadius.circular(14),
                                                    color: secondarycolor,
                                                  ),
                                                ),
                                              ),
                                              Column(
                                                crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                                children: [
                                                  SizedBox(
                                                    height: scrHeight * 0.024,
                                                  ),
                                                  Text(
                                                    "Name",
                                                    style: TextStyle(
                                                        fontSize: CardFont1,
                                                        color: Colors.grey,
                                                        fontFamily: 'Urbanist',
                                                        fontWeight:
                                                        FontWeight.w500),
                                                  ),
                                                  Text(
                                                    "New Chitti One",
                                                    style: TextStyle(
                                                      fontSize: CardFont2,
                                                      fontWeight: FontWeight.w700,
                                                      fontFamily: 'Urbanist',
                                                    ),
                                                  ),
                                                  SizedBox(
                                                    height:scrHeight* 0.005,
                                                  ),
                                                  Row(
                                                    mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceEvenly,
                                                    crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                    children: [
                                                      Text(
                                                        "Duration",
                                                        style: TextStyle(
                                                            fontSize: CardFont1,
                                                            color: Colors.grey,
                                                            fontFamily: 'Urbanist',
                                                            fontWeight:
                                                            FontWeight.w500),
                                                      ),
                                                      SizedBox(
                                                        width: scrWidth * 0.47,
                                                      ),
                                                      Text(
                                                        "Value",
                                                        style: TextStyle(
                                                            fontSize: CardFont1,
                                                            color: Colors.grey,
                                                            fontFamily: 'Urbanist',
                                                            fontWeight:
                                                            FontWeight.w500),
                                                      ),
                                                    ],
                                                  ),
                                                  Row(
                                                    children: [
                                                      Text(
                                                        "25 Months",
                                                        style: TextStyle(
                                                          fontSize: CardFont2,
                                                          fontWeight:
                                                          FontWeight.w700,
                                                          fontFamily: 'Urbanist',
                                                          color: primarycolor,
                                                        ),
                                                      ),
                                                      SizedBox(
                                                        width: scrWidth * 0.34,
                                                      ),
                                                      Text(
                                                        "₹50.000",
                                                        style: TextStyle(
                                                          fontSize: CardFont2,
                                                          fontWeight:
                                                          FontWeight.w700,
                                                          fontFamily: 'Urbanist',
                                                          color: primarycolor,
                                                        ),
                                                      )
                                                    ],
                                                  ),
                                                ],
                                              ),
                                            ],
                                          ),
                                          Divider(
                                            indent: 30,
                                            endIndent: 30,
                                          ),
                                          Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                            children: [
                                              SizedBox(
                                                height: scrHeight*0.034,
                                                width: scrWidth*0.23,
                                                child: ElevatedButton(
                                                  child: Text('Join'),
                                                  onPressed: () {
                                                    print('Hello');
                                                  },
                                                  style: ElevatedButton.styleFrom(
                                                      shape: RoundedRectangleBorder(
                                                        borderRadius: BorderRadius.circular(30),
                                                      ),
                                                      primary: primarycolor,
                                                      // padding: EdgeInsets.symmetric(horizontal: 50, vertical: 20),
                                                      textStyle: TextStyle(
                                                        fontFamily: 'Urbanist',
                                                        fontSize: 11,
                                                        fontWeight: FontWeight.w700,
                                                      )),

                                                ),
                                              ),
                                              SizedBox(width: scrWidth*0.31,),

                                              Column(
                                                crossAxisAlignment:
                                                CrossAxisAlignment.end,
                                                children: [

                                                  Text(
                                                    "Subscription",
                                                    style: TextStyle(
                                                        fontSize: CardFont1,
                                                        color: Colors.grey,
                                                        fontFamily: 'Urbanist',
                                                        fontWeight: FontWeight.w500),
                                                  ),
                                                  SizedBox(height: scrHeight*0.001,),
                                                  Row(
                                                    mainAxisAlignment:
                                                    MainAxisAlignment.end,
                                                    children: [
                                                      Text(
                                                        "₹2.000",
                                                        style: TextStyle(
                                                          fontSize: CardFont2,
                                                          fontWeight: FontWeight.w700,
                                                          fontFamily: 'Urbanist',
                                                          color: primarycolor,
                                                        ),
                                                      ),
                                                      Text(
                                                        "/month",
                                                        style: TextStyle(
                                                            fontSize: CardFont1,
                                                            color: Colors.grey,
                                                            fontFamily: 'Urbanist',
                                                            fontWeight:
                                                            FontWeight.w500),
                                                      ),
                                                    ],
                                                  )
                                                ],
                                              ),
                                              SizedBox(width: scrWidth*0.02,),
                                            ],
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              );
                            })
                      ],
                    ),
                  ),
                ],
              ))
        ],
      ),
    );
  }
//statefulbuilder is used in this bottom sheet ,that can change the state
  void bottomsheets(context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => StatefulBuilder(
        builder: (BuildContext context,
            void Function(void Function()) setState) {return Container(
          height: scrHeight * 0.33,
          decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(40),
                topRight: Radius.circular(40),
              )),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                height: scrHeight * 0.06,
              ),
              Padding(
                padding: EdgeInsets.only(left: 30),
                child: Text(
                  "Create New Room",
                  style: TextStyle(
                      fontFamily: 'Urbanist',
                      fontWeight: FontWeight.w700,
                      fontSize: scrWidth * 0.053),
                ),
              ),
              SizedBox(
                height: scrHeight * 0.05,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  InkWell(
                    onTap: (){
                      setState((){
                        selectedIndex = 1;
                      });
                    },
                    child: Column(
                      children: [
                        Badge(
                          padding: EdgeInsets.all(0),
                          badgeContent: selectedIndex == 1?Icon(
                            Icons.check,
                            color: primarycolor,
                            size: 17,
                          ):Container(),
                          child:Container(
                            width: scrWidth * 0.23,
                            height: scrHeight * 0.11,

                            decoration: BoxDecoration(shape: BoxShape.circle,color: Colors.grey.shade100,border:selectedIndex == 1?Border.all(color: primarycolor,width: 2,):Border.all(color: Colors.transparent),),

                          ),

                          badgeColor: Colors.white,
                          position: BadgePosition(
                            bottom: -7,
                          ),
                        ),
                        SizedBox(
                          height: scrHeight * 0.01,
                        ),
                        Text(
                            "Chit",
                            style: TextStyle(
                                fontFamily: 'Urbanist',
                                fontWeight: FontWeight.w500,
                                fontSize: CardFont2)),
                      ],
                    ),
                  ),
                  InkWell(
                    onTap: (){
                      setState((){
                        selectedIndex=0;
                      });

                    },
                    child: Column(
                      children: [
                        Badge(
                          padding: EdgeInsets.all(0),
                          badgeContent: selectedIndex == 0?Icon(
                            Icons.check,
                            color: primarycolor,
                            size: 17,
                          ):Container(),
                          child:Container(
                            width: scrWidth * 0.23,
                            height: scrHeight * 0.11,

                            decoration: BoxDecoration(shape: BoxShape.circle,color: Colors.grey.shade100,border:selectedIndex == 0?Border.all(color: primarycolor,width: 2,):Border.all(color: Colors.transparent),),

                          ),

                          badgeColor: Colors.white,
                          position: BadgePosition(
                            bottom: -7,
                          ),
                        ),
                        SizedBox(
                          height: scrHeight * 0.01,
                        ),
                        Text("Kuri",
                            style: TextStyle(
                                fontFamily: 'Urbanist',
                                fontWeight: FontWeight.w500,
                                fontSize: CardFont2))
                      ],
                    ),
                  ),
                  InkWell(
                    onTap: (){
                      setState((){
                        selectedIndex=2;
                      });
                    },
                    child:Column(
                      children: [
                        Badge(
                          padding: EdgeInsets.all(0),
                          badgeContent: selectedIndex == 2?Icon(
                            Icons.check,
                            color: primarycolor,
                            size: 17,
                          ):Container(),
                          child:Container(
                            width: scrWidth * 0.23,
                            height: scrHeight * 0.11,

                            decoration: BoxDecoration(shape: BoxShape.circle,color: Colors.grey.shade100,border:selectedIndex == 2?Border.all(color: primarycolor,width: 2,):Border.all(color: Colors.transparent),),

                          ),

                          badgeColor: Colors.white,
                          position: BadgePosition(
                            bottom: -7,
                          ),
                        ),
                        SizedBox(
                          height: scrHeight * 0.01,
                        ),
                        Text("Charity",
                            style: TextStyle(
                                fontFamily: 'Urbanist',
                                fontWeight: FontWeight.w500,
                                fontSize: CardFont2))
                      ],
                    ),

                  )

                ],
              ),
              SizedBox(
                height: scrHeight * 0.025,
              ),


              Center(
                child: Container(
                  height: scrHeight * 0.07,
                  width: scrWidth * 0.9,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: primarycolor,
                  ),
                  child: Center(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.add,
                          size: 21,
                          color: Colors.white,
                        ),
                        SizedBox(
                          width: scrWidth * 0.01,
                        ),
                        Text(
                          "Create Room",
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: FontSize17,
                              fontFamily: 'Urbanist',
                              fontWeight: FontWeight.w500),
                        )
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        );  },

      ),
    );
  }
}
