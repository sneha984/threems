import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';

class Utilities extends StatefulWidget {
  const Utilities({Key? key}) : super(key: key);

  @override
  State<Utilities> createState() => _UtilitiesState();
}

class _UtilitiesState extends State<Utilities> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Text("Utilities"),
      ),
    );
  }
}
// import 'package:fl_chart/fl_chart.dart';
// import 'package:flutter/material.dart';
// import 'package:threems/utils/themes.dart';
//
// class LineChartSample3 extends StatefulWidget {
//   final weekDays = const ['Sat', 'Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri','Sat', 'Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri'];
//
//   final List<double> yValues = const [1.3, 1, 1.8, 1.5, 2.2, 1.8, 3,4,5,6,7,8,9];
//
//   const LineChartSample3({Key? key}) : super(key: key);
//
//   @override
//   State createState() => _LineChartSample3State();
// }
//
// class _LineChartSample3State extends State<LineChartSample3> {
//   late double touchedValue;
//
//   @override
//   void initState() {
//     touchedValue = -1;
//     super.initState();
//   }
//
//   Widget leftTitleWidgets(double value, TitleMeta meta) {
//     const style = TextStyle(color: Colors.black, fontSize: 10);
//     String text;
//     switch (value.toInt()) {
//       case 0:
//         text = '';
//         break;
//       case 1:
//         text = '1k calories';
//         break;
//       case 2:
//         text = '2k calories';
//         break;
//       case 3:
//         text = '3k calories';
//         break;
//       default:
//         return Container();
//     }
//
//     return SideTitleWidget(
//       axisSide: meta.axisSide,
//       space: 6,
//       child: Text(text, style: style, textAlign: TextAlign.center),
//     );
//   }
//
//   Widget bottomTitleWidgets(double value, TitleMeta meta) {
//     final isTouched = value == touchedValue;
//     final style = TextStyle(
//       color: isTouched ? Colors.green: Colors.grey,
//       fontWeight: FontWeight.bold,
//     );
//
//     return SideTitleWidget(
//       space: 4,
//       child: Text(widget.weekDays[value.toInt()], style: style),
//       axisSide: meta.axisSide,
//     );
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Column(
//       mainAxisSize: MainAxisSize.min,
//       crossAxisAlignment: CrossAxisAlignment.center,
//       mainAxisAlignment: MainAxisAlignment.center,
//       children: <Widget>[
//         SizedBox(height: 200,),
//         Row(
//           mainAxisSize: MainAxisSize.min,
//           children: const <Widget>[
//             Text(
//               'Average Line',
//               style: TextStyle(
//                   color: Colors.green,
//                   fontWeight: FontWeight.bold,
//                   fontSize: 16),
//             ),
//             Text(
//               ' and ',
//               style: TextStyle(
//                   color: Colors.black,
//                   fontWeight: FontWeight.bold,
//                   fontSize: 16),
//             ),
//             Text(
//               'Indicators',
//               style: TextStyle(
//                   color: Colors.blue,
//                   fontWeight: FontWeight.bold,
//                   fontSize: 16),
//             ),
//           ],
//         ),
//         const SizedBox(
//           height: 18,
//         ),
//         SingleChildScrollView(
//           scrollDirection: Axis.horizontal,
//           child: SizedBox(
//             width: 1000,
//             height: 280,
//             child: LineChart(
//               LineChartData(
//                 lineTouchData: LineTouchData(
//                     getTouchedSpotIndicator:
//                         (LineChartBarData barData, List<int> spotIndexes) {
//                       return spotIndexes.map((spotIndex) {
//                         final spot = barData.spots[spotIndex];
//                         if (spot.x == 0 || spot.x == 6) {
//                           return null;
//                         }
//                         return TouchedSpotIndicatorData(
//                           FlLine(color: Colors.blue, strokeWidth: 4),
//                           FlDotData(
//                             getDotPainter: (spot, percent, barData, index) {
//                                 return FlDotCirclePainter(
//                                     radius: 8,
//                                     color: Colors.white,
//                                     strokeWidth: 5,
//                                     strokeColor: primarycolor);
//                                 },
//                           ),
//                         );
//                       }).toList();
//                     },
//                     touchTooltipData: LineTouchTooltipData(
//                         tooltipBgColor: Colors.blueAccent,
//                         getTooltipItems: (List<LineBarSpot> touchedBarSpots) {
//                           return touchedBarSpots.map((barSpot) {
//                             final flSpot = barSpot;
//                             if (flSpot.x == 0 || flSpot.x == 6) {
//                               return null;
//                             }
//
//                             // TextAlign textAlign;
//                             // switch (flSpot.x.toInt()) {
//                             //   case 1:
//                             //     textAlign = TextAlign.left;
//                             //     break;
//                             //   case 5:
//                             //     textAlign = TextAlign.right;
//                             //     break;
//                             //   default:
//                             //     textAlign = TextAlign.center;
//                             // }
//
//                             return LineTooltipItem(
//                               '${widget.weekDays[flSpot.x.toInt()]} \n',
//                               const TextStyle(
//                                 color: Colors.white,
//                                 fontWeight: FontWeight.bold,
//                               ),
//                               children: [
//                                 TextSpan(
//                                   text: flSpot.y.toString(),
//                                   style: TextStyle(
//                                     color: Colors.grey[100],
//                                     fontWeight: FontWeight.normal,
//                                   ),
//                                 ),
//                                 const TextSpan(
//                                   text: ' k ',
//                                   style: TextStyle(
//                                     fontStyle: FontStyle.italic,
//                                     fontWeight: FontWeight.normal,
//                                   ),
//                                 ),
//                                 const TextSpan(
//                                   text: 'calories',
//                                   style: TextStyle(
//                                     fontWeight: FontWeight.normal,
//                                   ),
//                                 ),
//                               ],
//                             );
//                           }).toList();
//                         }),
//                     touchCallback:
//                         (FlTouchEvent event, LineTouchResponse? lineTouch) {
//                       if (!event.isInterestedForInteractions ||
//                           lineTouch == null ||
//                           lineTouch.lineBarSpots == null) {
//                         setState(() {
//                           touchedValue = -1;
//                         });
//                         return;
//                       }
//                       final value = lineTouch.lineBarSpots![0].x;
//
//                       if (value == 0 || value == 6) {
//                         setState(() {
//                           touchedValue = -1;
//                         });
//                         return;
//                       }
//
//                       setState(() {
//                         touchedValue = value;
//                       });
//                     }),
//
//                 lineBarsData: [
//                   LineChartBarData(
//
//                     spots: widget.yValues.asMap().entries.map((e) {
//                       return FlSpot(e.key.toDouble(), e.value);
//                     }).toList(),
//                     isCurved: true,
//                     barWidth: 4,
//                     color: primarycolor,
//                     belowBarData: BarAreaData(
//                       show: true,
//                       gradient: LinearGradient(
//                         colors: [
//                           Colors.green.withOpacity(0.5),
//                           Colors.green.withOpacity(0.0),
//                         ],
//                         stops: const [0.5, 1.0],
//                         begin: Alignment.topCenter,
//                         end: Alignment.bottomCenter,
//                       ),
//                       spotsLine: BarAreaSpotsLine(
//                         show: true,
//                         flLineStyle: FlLine(
//                           color: Colors.blue,
//                           strokeWidth: 2,
//                         ),
//                         checkToShowSpotLine: (spot) {
//                           if (spot.x == 0 || spot.x == 6) {
//                             return false;
//                           }
//
//                           return true;
//                         },
//                       ),
//                     ),
//                     dotData: FlDotData(
//                         show: true,
//                         getDotPainter: (spot, percent, barData, index) {
//                             return FlDotCirclePainter(
//                                 radius: 6,
//                                 color: Colors.white,
//                                 strokeWidth: 4,
//                                 strokeColor: primarycolor);
//
//                         },
//                         checkToShowDot: (spot, barData) {
//                           return spot.x != 0 && spot.x != 6;
//                         }),
//                   ),
//                 ],
//                 minY: 0,
//                 gridData: FlGridData(
//                   show: false,
//
//                 ),
//                 titlesData: FlTitlesData(
//                   show: true,
//                   topTitles: AxisTitles(
//                     sideTitles: SideTitles(showTitles: false),
//                   ),
//                   rightTitles: AxisTitles(
//                     sideTitles: SideTitles(showTitles: false),
//                   ),
//                   leftTitles: AxisTitles(
//                     sideTitles: SideTitles(
//                       showTitles: true,
//                       reservedSize: 46,
//                       getTitlesWidget: leftTitleWidgets,
//                     ),
//                   ),
//                   bottomTitles: AxisTitles(
//                     sideTitles: SideTitles(
//                       showTitles: true,
//                       reservedSize: 40,
//                       getTitlesWidget: bottomTitleWidgets,
//                     ),
//                   ),
//                 ),
//               ),
//             ),
//           ),
//         ),
//       ],
//     );
//   }
// }


// Container(
// height: 500,
// width: 500,
// child: SfRadialGauge(
// axes: <RadialAxis>[
// // Create primary radial axis
// RadialAxis(
// minimum: 0,
// interval: 1,
// maximum: 360,
// showLabels: false,
// showLastLabel: false,
// showTicks: false,
// startAngle: 270,
// endAngle: 270,
// radiusFactor: 0.3,
// axisLineStyle: AxisLineStyle(
// thickness:0.2,
// color: Colors.grey.withOpacity(0.2),
// thicknessUnit: GaugeSizeUnit.factor,
// ),
// pointers: <GaugePointer>[
// RangePointer(
// value: 240,
// enableAnimation: true,
// animationDuration: 6000,
// animationType: AnimationType.slowMiddle,
// width: 0.21,
// sizeUnit: GaugeSizeUnit.factor,
// cornerStyle: CornerStyle.startCurve,
// gradient: const SweepGradient(colors: <Color>[
// primarycolor,
// Color(0xff96c8aa)
// ],
// stops: <double>[
// 0.74,
// 0.99
// ])),
// MarkerPointer(
// enableAnimation: true,
// animationDuration: 6000,
// animationType: AnimationType.slowMiddle,
// value: 240,
// markerWidth: 17,
// markerHeight: 17,
// borderWidth:5,
// borderColor:  Color(0xff96c8aa),
// markerType: MarkerType.circle,
// color: Colors.white,
// )
// ],
// annotations:<GaugeAnnotation> [
// GaugeAnnotation(angle: 0,positionFactor: 0.18,
// widget:Text("50%",textAlign: TextAlign.center,style: TextStyle(
// fontSize: 23,fontFamily: 'Urbanist',fontWeight: FontWeight.w600
// ),),
// )
//
// ],
//
// )
// ]),
// )

