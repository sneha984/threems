import 'package:flutter/material.dart';
import 'dart:ui' as ui;
import 'package:threems/screens/splash_screen.dart';

class BuyAndSell extends StatefulWidget {
  const BuyAndSell({Key? key}) : super(key: key);

  @override
  State<BuyAndSell> createState() => _BuyAndSellState();
}

class _BuyAndSellState extends State<BuyAndSell> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(child: Text('Buy And Sell')),
    );
  }
}
